
public class HundirLaFlota {
	public static void main(String[] args) {
		Tablero t1 = new Tablero();
		t1.imprimeTablero();
}
}
