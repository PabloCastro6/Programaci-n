
public class Constantes {
public static final int Numero_Filas_Columnas=16;  //numero de filas y columnas del Tablero
public static final int Numero_Barcos_Una_Casilla= 3; 
public static final int Numero_Barcos_Dos_Casillas=2;
public static final int Numero_Barcos_Tres_Casillas=3;
public static final int Oportunidades_Disparo = 10; //Oportunidades
}
