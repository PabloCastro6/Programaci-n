
public class Constantes {

	public static final String DIRECTORIO_DESTINO = System.getProperty("user.dir")+"\\ficherosCopiados\\";
	public static final String DIRETORIO_LOG = System.getProperty("user.dir")+"\\logs\\";
}

